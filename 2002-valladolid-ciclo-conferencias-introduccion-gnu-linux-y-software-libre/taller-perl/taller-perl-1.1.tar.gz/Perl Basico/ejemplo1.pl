#!/usr/bin/perl -w
#-----------------------------------------------------------------------------
#   Taller de Perl v 1.0   Francisco J. Palacios   <wrider@sourceforge.net>
#-----------------------------------------------------------------------------

# El tipico hola mundo en varios sabores

print 'Hola mundo\n';	# 1. No hay sustitucion del \n
print "Hola mundo\n";	# 2. Si hay sustitucion
print("Hola mundo\n");	# 3. Notacion funcional, totalmente equivalente a 2.

